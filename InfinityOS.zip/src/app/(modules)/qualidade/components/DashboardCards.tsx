\
"use client";

import { motion } from "framer-motion";
import {
  CheckCircle2,
  Clock3,
  AlertTriangle,
  Link2,
  User,
  CalendarDays,
} from "lucide-react";

export interface DashboardCardsProps {
  progresso: number;
  producao: number;
  instalacao: number;
  fimObra: number;
  pendencias: number;
  portalAtivo: boolean;
  responsavel: string;
  ultimaAtualizacao: string;
}

const cards = (p: DashboardCardsProps) => [
  {
    title: "Progresso",
    value: `${p.progresso}%`,
    icon: CheckCircle2,
  },
  {
    title: "Checklists",
    value: `${p.producao + p.instalacao + p.fimObra}/3`,
    icon: Clock3,
  },
  {
    title: "Pendências",
    value: String(p.pendencias),
    icon: AlertTriangle,
  },
  {
    title: "Portal",
    value: p.portalAtivo ? "Ativo" : "Pendente",
    icon: Link2,
  },
];

export default function DashboardCards(props: DashboardCardsProps) {
  return (
    <section className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {cards(props).map((card, index) => {
          const Icon = card.icon;
          return (
            <motion.div
              key={card.title}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.08 }}
              className="rounded-2xl border bg-white p-5 shadow-sm dark:bg-zinc-900"
            >
              <div className="flex items-center justify-between">
                <span className="text-sm text-zinc-500">{card.title}</span>
                <Icon className="h-5 w-5 text-yellow-500" />
              </div>

              <p className="mt-4 text-3xl font-bold">{card.value}</p>
            </motion.div>
          );
        })}
      </div>

      <div className="rounded-2xl border bg-white p-6 shadow-sm dark:bg-zinc-900">
        <div className="mb-3 flex items-center justify-between">
          <span className="font-semibold">Andamento da Entrega</span>
          <span>{props.progresso}%</span>
        </div>

        <div className="h-3 overflow-hidden rounded-full bg-zinc-200">
          <motion.div
            className="h-full rounded-full bg-yellow-500"
            initial={{ width: 0 }}
            animate={{ width: `${props.progresso}%` }}
          />
        </div>

        <div className="mt-6 grid gap-4 md:grid-cols-2">
          <div className="flex items-center gap-3">
            <User className="h-5 w-5 text-yellow-500" />
            <div>
              <p className="text-xs text-zinc-500">Responsável</p>
              <p className="font-medium">{props.responsavel}</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <CalendarDays className="h-5 w-5 text-yellow-500" />
            <div>
              <p className="text-xs text-zinc-500">Última atualização</p>
              <p className="font-medium">{props.ultimaAtualizacao}</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
