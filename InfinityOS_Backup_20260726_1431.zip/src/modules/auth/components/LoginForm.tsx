"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";

import { PasswordField } from "./PasswordField";
import { useAuth } from "../hooks/useAuth";
import {
  loginSchema,
  type LoginFormData,
} from "../schemas/login.schema";

export function LoginForm() {
  const router = useRouter();
  const { signIn } = useAuth();

  const [loading, setLoading] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  async function onSubmit(data: LoginFormData) {
    try {
      setLoading(true);
      setLoginError(null);

      console.log("1 - Iniciando autenticação");

      await signIn(data);

      console.log("2 - Autenticação concluída");

      router.replace("/");

      console.log("3 - Redirecionamento solicitado");
    } catch (error) {
      console.error("Erro completo ao realizar login:", error);

      const message =
        error instanceof Error
          ? error.message
          : "Ocorreu um erro desconhecido ao realizar o login.";

      setLoginError(message);
      alert(message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <form
      onSubmit={handleSubmit(onSubmit)}
      className="space-y-5"
      noValidate
    >
      <div>
        <label
          htmlFor="email"
          className="mb-2 block text-sm text-zinc-300"
        >
          E-mail
        </label>

        <input
          id="email"
          type="email"
          autoComplete="email"
          placeholder="Digite seu e-mail"
          disabled={loading}
          {...register("email")}
          className="w-full rounded-lg border border-zinc-800 bg-zinc-950 px-4 py-3 text-white outline-none transition placeholder:text-zinc-600 focus:border-yellow-400 disabled:cursor-not-allowed disabled:opacity-60"
        />

        {errors.email && (
          <p className="mt-2 text-sm text-red-400">
            {errors.email.message}
          </p>
        )}
      </div>

      <div>
        <label
          htmlFor="password"
          className="mb-2 block text-sm text-zinc-300"
        >
          Senha
        </label>

        <PasswordField
          id="password"
          autoComplete="current-password"
          placeholder="Digite sua senha"
          disabled={loading}
          {...register("password")}
        />

        {errors.password && (
          <p className="mt-2 text-sm text-red-400">
            {errors.password.message}
          </p>
        )}
      </div>

      {loginError && (
        <div
          role="alert"
          className="rounded-lg border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-300"
        >
          {loginError}
        </div>
      )}

      <button
        type="submit"
        disabled={loading}
        className="w-full rounded-lg bg-yellow-400 py-3 font-semibold text-black transition hover:bg-yellow-300 disabled:cursor-not-allowed disabled:opacity-60"
      >
        {loading ? "Entrando..." : "Entrar"}
      </button>
    </form>
  );
}
